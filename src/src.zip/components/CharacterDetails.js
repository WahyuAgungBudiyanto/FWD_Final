import React, { useEffect } from "react";
import { Link, useParams } from "react-router-dom";

const CharacterDetails = (props) => {
  const { charId } = useParams();
  console.log(props.characters.data["count"]);
  /*
  useEffect(
    () => {
      // hit TMDB endpoint to get details of a movie
      fetch(`https://gateway.marvel.com/v1/public/characters/${charId}?ts=1&apikey=f1698f16039e961fc54d26df5fc42a45&hash=64deefa1d0cc0e6f4be0bfa6c27a9abd`)
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          // setCharacters(data);
        });
    },
    // eslint-disable-next-line
    []
  ); */
  return "1";
  /*
  return (
    <section className="py-5">
      <div className="container px-4 px-lg-5 my-5">
        <div className="col-md-6">
          <img className="card-img-top mb-5 mb-md-0" src={props.character.thumbnail.path + "." + props.character.thumbnail.extension} alt={props.name} />
        </div>
        <div className="col-md-6">
          <h1 className="display-5 fw-bolder">{props.character.name}</h1>

          <p className="lead">{props.character.description}</p>
          <div className="d-flex">
            <Link className="btn btn-outline-dark flex-shrink-0" to="/">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </section>
  );*/
};

export default CharacterDetails;
