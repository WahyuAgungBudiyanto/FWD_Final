import React from "react";
import { Link } from "react-router-dom";

const CharacterDetails = (props) => {
  const imageUrl = "http://i.annihil.us/u/prod/marvel/i/mg/6/20/52602f21f29ec";

  return (
    <section className="py-5">
      <div className="container px-4 px-lg-5 my-5">
        <div className="row gx-4 gx-lg-5 align-items-center">
          <div className="col-md-6">
            <img className="card-img-top mb-5 mb-md-0" src={imageUrl + props.character.results.thumbnail.path} alt={props.character.name} />
          </div>
          <div className="col-md-6">
            <div className="small mb-1">Release Date: {props.character.modified}</div>
            <h1 className="display-5 fw-bolder">{props.character.name}</h1>

            <p className="lead">{props.character.description}</p>
            <div className="d-flex">
              <Link className="btn btn-outline-dark flex-shrink-0" to="/">
                Back to Home
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CharacterDetails;
